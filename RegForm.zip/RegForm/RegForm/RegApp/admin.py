from django.contrib import admin
from RegApp.models import UserProfileInfo,User


# Register your models here.
admin.site.register(UserProfileInfo)